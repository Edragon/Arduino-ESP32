rootProject.name = "esp32Audio"
